# Phaser 3 / Phaser 4

```js
preload() {
  this.load.atlas('tiny-dungeon-tilemap', 'tiny-dungeon-tilemap.png', 'tiny-dungeon-tilemap.json');
}
create() {
  const sprite = this.add.sprite(100, 100, 'tiny-dungeon-tilemap', 'tiny-dungeon-tilemap_000');
}
```

* Pixel art: create the game with `pixelArt: true` (nearest filtering, rounded positions).
* Frame names are the keys in the JSON; trimmed frames keep their full size and offset.
* Durations are per frame in milliseconds; ping-pong animations use `yoyo`.
* Loaded and drawn by Phaser 3.90 and 4.2 in tools/engine-verify (docs/STUDIO-PACK.md).
